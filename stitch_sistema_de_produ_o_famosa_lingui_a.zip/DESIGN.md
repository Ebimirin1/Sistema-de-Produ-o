---
name: Famosa Industrial Ops
colors:
  surface: '#fff8f7'
  surface-dim: '#e6d6d5'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0ef'
  surface-container: '#fbeae8'
  surface-container-high: '#f5e5e3'
  surface-container-highest: '#efdfdd'
  on-surface: '#221a19'
  on-surface-variant: '#5a413d'
  inverse-surface: '#382e2d'
  inverse-on-surface: '#feedeb'
  outline: '#8e706b'
  outline-variant: '#e2beb9'
  surface-tint: '#b4271c'
  primary: '#630001'
  on-primary: '#ffffff'
  primary-container: '#8c0303'
  on-primary-container: '#ff9283'
  inverse-primary: '#ffb4a9'
  secondary: '#a43b2f'
  on-secondary: '#ffffff'
  secondary-container: '#fd7d6c'
  on-secondary-container: '#71150f'
  tertiary: '#402800'
  on-tertiary: '#ffffff'
  tertiary-container: '#5d3c00'
  on-tertiary-container: '#eaa224'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4a9'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#910906'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4a9'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#84231a'
  tertiary-fixed: '#ffddb2'
  tertiary-fixed-dim: '#ffb94e'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#fff8f7'
  on-background: '#221a19'
  surface-variant: '#efdfdd'
  brand-accent-red: '#D90404'
  brand-ink: '#260101'
  surface-page: '#F8F6F4'
  surface-card: '#FFFFFF'
  border-subtle: '#E8E1DF'
  status-success: '#176B45'
  status-info: '#205A85'
  status-warning-bg: '#FFF2D6'
  status-warning-text: '#4A2C00'
  status-danger-bg: '#FDE8E8'
  status-danger-text: '#8C0303'
typography:
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 21px
  label-md:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Public Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  numeric-table:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system serves a high-throughput charcuterie manufacturing facility, bridging the precision of industrial floor execution with the rigorous oversight of plant supervision. The operational philosophy rejects decorative distraction in favor of functional clarity, uncompromised legibility under harsh factory lighting, and high-speed data entry.

The style is an authoritative, utilitarian evolution of **Industrial Modernism**:
- **Clarity over ornament:** Generous white surface space for operational data, anchored by a deep heritage wine (`#590202`) and authoritative carmine red (`#8C0303`).
- **Tactile feedback & safety:** High-contrast color assignments for warnings, status indicators, and critical blocking actions (e.g., maximum batch capacity alerts, seasoning discrepancies).
- **Target audience:** Plant floor operators entering weights and confirming mixing sequences, shift leaders monitoring batch curing times, and logistics supervisors managing vacuum packaging and partner fulfillment.
- **Emotional tone:** Trustworthy, sturdy, unyielding, and punctual. It commands respect like an industrial dial gauge or a precision meat processing plant terminal.

## Colors

The palette balances heritage artisanal butchery with disciplined industrial process control:

- **Primary (`#8C0303` - Deep Red):** Designates prominent headers, primary action confirmations ("Liberar embutimento", "Gravar OP"), and high-level section titles on light backgrounds.
- **Secondary (`#590202` - Wine):** Controls system architecture, permanent lateral navigation, and dense master-view rail containers.
- **Tertiary / Warning (`#D99311` - Industrial Ochre):** Reserved for batch curing timers, capacity thresholds, active status badges, and brand highlights. Never applied as body text on light backgrounds.
- **Brand Accent Red (`#D90404`):** Dynamic active states, critical validation errors, and high-priority callouts.
- **Neutral Base (`#260101` - Near Black Ink):** High-density text, table values, and stark contrast elements against canvas.
- **Surface Neutrals:** `#F8F6F4` for page backdrop; `#FFFFFF` for data-entry containers and elevation surfaces; `#E8E1DF` for low-contrast structure lines; `#5C5150` for secondary metadata and auxiliary unit notation.

Never rely solely on color to communicate state. Combine tokens with explicit status labels (e.g., "Em cura (12h restantes)", "Bloqueado: Capacidade > 150 kg") and standard iconography.

## Typography

The type scale combines an authoritative editorial serif for brand identity and high-level page headers (`Noto Serif`, complementing the artisanal character of Ruwudu) with a clean, highly legible grotesque (`Public Sans` / `system-ui`) optimized for rapid scanning of batch IDs, formula weights, and verification tables.

### Operational Rules:
- **Numerical Alignment:** All numerical outputs in data grids, batch calculators, and staging receipts must be right-aligned with tabular figures (`font-variant-numeric: tabular-nums`).
- **Unit Representation:** Units of measure (`kg`, `g`, `un`, `ml`) must be styled with explicit secondary weight (`#5C5150`) directly adjacent to the quantitative value (e.g., `145,50 kg`).
- **Date Formatting:** Strict adherence to Brazilian Portuguese syntax (`dd/mm/aaaa` or `dd/mm/aaaa hh:mm`).
- **Display Restraint:** Serif headlines are restricted to page titles and system signatures. All functional labels, operational warnings, forms, and table cells employ `Public Sans`.

## Layout & Spacing

The layout adopts a disciplined **Fluid Operational Grid** that adjusts from desktop control consoles down to ruggedized tablet and mobile views.

- **Desktop (≥1024px):** Fixed navigation rail (240px wide) set against `#590202`. Fluid 12-column content container with `1.5rem` gutters and `2rem` outer padding. Dense data grids expand across columns 1–12, while forms adopt split master-detail layouts (8 columns data, 4 columns batch validation summaries).
- **Tablet (768px – 1023px):** Condensed navigation rail (64px icon-only). 8-column layout with `1rem` gutters and `1.5rem` outer canvas padding.
- **Mobile (<768px):** Collapsible top header navigation. Single-column stacked layout (`margin: 1rem`). High-density data tables transform into distinct vertical record cards retaining order numbers, batch limits, status chips, and action triggers.

## Elevation & Depth

To maintain clarity in glare-prone production areas, depth is communicated primarily through **tonal separation and crisp structural outlines** rather than diffuse shadows.

- **Level 0 (Canvas Base):** Background canvas rendered in `#F8F6F4`.
- **Level 1 (Operational Surfaces & Cards):** Pure white (`#FFFFFF`) containers framed with a crisp `1px solid #E8E1DF` border. Flat, high-contrast separation without drop shadows.
- **Level 2 (Active Focus & Sticky Rail Headers):** Inset highlights or crisp border shifts (`#8C0303` or `#590202`). Sticky table headers use flat white `#FFFFFF` with a bottom rule of `2px solid #E8E1DF`.
- **Level 3 (Modals, Confirmation Overlays, and Drawers):** Used strictly for irreversible operational actions (e.g., overriding recipe weights, breaking batch seals). Backed by a high-contrast dark scrim (`#260101` at 65% opacity) with a directional shadow: `0 8px 24px rgba(38, 1, 1, 0.18)`.

## Shapes

The interface embraces a functional, calibrated **Soft (`roundedness: 1`)** geometry:
- **Base Components:** Inputs, standard buttons, badge containers, and form fields use `4px` (`0.25rem`) corner rounding. This reinforces the industrial utility and tool-like precision of physical manufacturing machinery.
- **Cards & Data Groups:** Table wrappers and batch cards use `8px` (`0.5rem`) rounding (`rounded-lg`) to gently separate complex information groups.
- **Modals & Overlays:** Capped at `12px` (`0.75rem`) rounding (`rounded-xl`).
- **Interactive Checkboxes & Segmented Controls:** Crisp `3px` corner radius to retain mechanical clarity. Circular radios for mutual exclusivity.

## Components

### Buttons & Operational Actions
- **Primary Button:** Background `#8C0303`, text `#FFFFFF`, minimum height `44px` (touch-target compliant for floor operators wearing gloves). Active verbs must be stated in full (e.g., "Liberar embutimento", "Confirmar mistura"). Hover state deepens to `#590202`.
- **Secondary Button:** Surface `#FFFFFF`, text `#590202`, border `1px solid #590202`.
- **Destructive / Alert Action:** Background `#D90404`, text `#FFFFFF`.
- **Touch-safe Metrics:** Padding `0.75rem 1.25rem`, tracking `0.02em`, font-weight 600.

### Input Fields & Selectors
- **Labeling:** Permanent label situated above the field in `Public Sans` 12px semibold (`#260101`). Never rely on placeholder text as a label substitute.
- **Field Styling:** Height `44px`, background `#FFFFFF`, border `1px solid #E8E1DF`, border-radius `4px`.
- **Focus State:** 2px ring `#8C0303` with a 2px offset.
- **Unit Accompaniment:** Numerical inputs requiring units display a static right-side affix container (`kg`, `g`, `un`) shaded in `#F8F6F4` with `#5C5150` text.

### Industrial Status Badges (Chips)
- **Draft / Planejada:** Neutral grey-brown (`#5C5150` text, `#F8F6F4` background, `#E8E1DF` border).
- **Em Cura / Atenção:** Ochre tone (`#4A2C00` text, `#FFF2D6` background, `#D99311` left border strip). Must show cure completion time.
- **Liberado / Sucesso:** Evergreen (`#176B45` text, `#E8F5E9` background, `#176B45` border).
- **Bloqueado / Excesso:** Crimson (`#8C0303` text, `#FDE8E8` background, `#D90404` border).

### Tables & Massada Grids
- **Header:** Sticky top, uppercase 12px `#5C5150`, background `#FFFFFF`, border-bottom `2px solid #E8E1DF`.
- **Alignment:** Alphanumeric IDs and descriptors left-aligned; batch quantities, dates, and mass values right-aligned.
- **Batch Safety Indicator (Max 150 kg):** Summed meat + seasoning calculator row displays dynamic state: green while `≤ 150 kg`, immediate red banner alert and primary button disablement if `> 150 kg`.

### Confirmation Dialogs
Modals must summarize the operational consequence prior to commit: identify affected Order (OP), list delta weights, and require an explicit secondary confirmation click.